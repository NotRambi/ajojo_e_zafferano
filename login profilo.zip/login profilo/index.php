<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login e Profilo</title>
    <style>
    /* Stile per il pulsante */
    .button {
        display: block;
        margin: 20px auto;
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        text-decoration: none;
        width: 10%;
        text-align: center;
    }

    /* Stile per il modal */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.5);
        z-index: 1;
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 400px;
    }
    .close:hover,
    .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
    }
</style>
</head>
<body>

 


    <!-- pulsanti -->
<a id="loginBtn" class="button" href="#">Login/SignIn</a>
<a id="profileBtn" class="button" style="display:none;" href="profilo.php">Profilo</a>



<?php
    //DATABASE:
    $dbconn = pg_connect("host=localhost port=5432 dbname=ajojo user=postgres password=biar") 
    or die('Could not connect: ' . pg_last_error());    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $tipo = $_POST['tipo'];
        //CASO LOGIN
        if($tipo == "login"){
            $username = $_POST['username'];
            $password = $_POST['password'];
            $query = "SELECT * FROM utenti WHERE username = '$username' AND password = '$password'";
            $result = pg_query($dbconn, $query);
            if ($result) {
                if (pg_num_rows($result) > 0) {
                    echo "Accesso consentito!";
                    //nascondo login e mostro profilo
                    echo "<script>document.getElementById('profileBtn').style.display = 'block';</script>";
                    echo "<script>document.getElementById('loginBtn').style.display = 'none';</script>";
                    session_start();
                    $_SESSION['user'] = $username;
                } else {
                    echo "Nome utente o password non validi.";
                }
            } else {
                echo "Errore nella ricerca dell'utente: " . pg_last_error($dbconn);
            }
            pg_free_result($result);
        }
        //CASO REGISTRAZIONE
        if($tipo == "registrazione"){
            $username = $_POST['username'];
            $password = $_POST['password'];
            $nome = $_POST['nome'];
            $cognome = $_POST['cognome'];
            if(!isset($_POST['isvegan'])) $isvegan="false"; else
                $isvegan = $_POST['isvegan'];
            if(!isset($_POST['intgluten'])) $intgluten = "false"; else
                $intgluten = $_POST['intgluten'];


            if($username==""||$password=="")
                echo "Registrazione fallita<br>inserisci i dati correttamente";
            else{
                $query="insert into utenti values ('$username','$nome','$cognome','$password',$isvegan,$intgluten); ";
                pg_query($dbconn, $query);
                echo "query returned succesfully";  
            }
        }
    }
    pg_close($dbconn);    
    ?>



<!-- Modal di login -->
<div id="loginModal" class="modal">
  <div class="modal-content">
  <span class="close" onclick="document.getElementById('loginModal').style.display='none'">&times;</span>
    <h2>Login</h2>
    <!-- Inserire qui il form di login -->
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="tipo" value="login">
        <label>Username:</label><br>
        <input type="text" id="username" name="username"><br>
        <label>Password:</label><br>
        <input type="text" id="password" name="password"><br><br>        
    <input type="submit" value="Accedi">
    </form>
    <p>Non hai un account? <a href="#" onclick="document.getElementById('registerModal').style.display='block'; document.getElementById('loginModal').style.display='none'">Registrati</a></p>
  </div>
</div>

<!-- Modal di registrazione -->
<div id="registerModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="document.getElementById('registerModal').style.display='none'">&times;</span>
    <h2>Registrazione</h2>
    <!-- Form di registrazione qui -->
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="tipo" value="registrazione">
        <label>Username:</label><br>
        <input type="text" id="username" name="username"><br>
        <label>Password:</label><br>
        <input type="text" id="password" name="password"><br>   
        <label>Nome:</label><br>
        <input type="text" id="nome" name="nome"><br>
        <label>Cognome:</label><br>
        <input type="text" id="cognome" name="cognome"><br>
        <label>Sei intollerante al glutine? <input type="checkbox" name="intgluten" value="true"> </label> <br>
        <label>Sei vegano? <input type="checkbox" name="isvegan" value="true" > </label><br>
        <br> <input type="submit" value="Registrati">
    </form>
    <p>torna al login: <a href="#" onclick="document.getElementById('loginModal').style.display='block'; document.getElementById('registerModal').style.display='none'">login</a></p>
  </div>
</div>

<script>
// Fa apparire il modal del login
document.getElementById('loginBtn').addEventListener('click', function(event) {
    document.getElementById('loginModal').style.display = 'block';
});

// Chiudi il modal cliccando fuori
window.onclick = function(event) {
  if (event.target == document.getElementById('loginModal')) {
    document.getElementById('loginModal').style.display = "none";
  }
  if (event.target == document.getElementById('registerModal')) {
    document.getElementById('registerModal').style.display = "none";
  }
}
</script>
    
</body>
</html>