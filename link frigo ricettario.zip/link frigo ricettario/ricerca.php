<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
    //database:
    $dbconn = pg_connect("host=localhost port=5432 dbname=ajojo user=postgres password=biar") 
    or die('Could not connect: ' . pg_last_error());

    $numcampi=3;//CAPIRE COME PASSARE STO VALORE -> <input type="hidden" name="numcampi" value="3">
                                                    //CAPIRE COME AGGIORNARE QUEL VALUE SU FRIGO
    $numcampi = $_POST['numcampi'];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //COSTRISCO LA QUERY:
    $query = "(SELECT distinct ricetta from ingredienti)except select distinct ricetta from(select * from ingredienti";
    $campi_valori = array();
    for ($i = 1; $i <= $numcampi; $i++) {
        $ingrediente = "ingrediente$i";
        $campi_valori[$ingrediente] = pg_escape_string($_POST[$ingrediente]);
    }
    $condizioni = array();
    foreach ($campi_valori as $ingrediente => $valore) {
        $condizioni[] = "ingrediente != '$valore'";
    }  
    $condizioni_sql = implode(" AND ", $condizioni); 
    if (!empty($condizioni_sql)) {
        $query .= " WHERE $condizioni_sql";
    }
    $query.= ")";

    //Esecuzione e stampa query
    $result = pg_query($dbconn, $query);
    while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
        echo "\t<tr>\n";
        foreach ($line as $col_value) {
            echo "\t\t<td>$col_value</td><br>";
        }
        echo "\t</tr>\n";
    }
    echo "</table>\n";
    } else {
        echo "Errore" . pg_last_error($dbconn);
    }

    
        pg_free_result($result);
    pg_close($dbconn);
    
    
    ?>
    
</form>
</body>
</html>